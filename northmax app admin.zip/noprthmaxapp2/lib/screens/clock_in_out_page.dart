import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ClockInOutPage extends StatefulWidget {
  const ClockInOutPage({super.key});

  @override
  _ClockInOutPageState createState() => _ClockInOutPageState();
}

class _ClockInOutPageState extends State<ClockInOutPage> {
  bool _isClockedIn = false;

  Future<void> _toggleClockInOut() async {
    setState(() {
      _isClockedIn = !_isClockedIn;
    });

    // Save the clock-in status to local storage
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isClockedIn', _isClockedIn);
  }

  @override
  void initState() {
    super.initState();
    _loadClockInStatus();
  }

  Future<void> _loadClockInStatus() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isClockedIn = prefs.getBool('isClockedIn') ?? false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Clock In/Out')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(_isClockedIn ? 'Clocked In' : 'Clocked Out'),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _toggleClockInOut,
              child: Text(_isClockedIn ? 'Clock Out' : 'Clock In'),
            ),
          ],
        ),
      ),
    );
  }
}
